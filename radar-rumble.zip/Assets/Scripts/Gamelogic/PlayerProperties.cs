﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerProperties : MonoBehaviour {
    public bool isFacingRight;
    public bool isGrounded;
    public bool isWalking;
    public bool isShooting;
}
